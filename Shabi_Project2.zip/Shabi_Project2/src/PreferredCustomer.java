/**
* Program Name:		PreferredCustomer.java
* @author		    Meenu Shabi 0908938
* Date:   		 	Dec 4, 2019
* Purpose:			To create a template for PrefferedCustomer object, extends RetailCustomer
*/

public class PreferredCustomer extends RetailCustomer
{
	//Declare instance variables
	private int cashbackRate;
		
	/**
	  * Constructs a new PreferredCustomer object
	  * @param firstName initializes First name 
	  * @param lastName initializes Last name
	  * @param customerLevel initializes Customer level
	  * @param totalPurchases initializes Total purchases
	  * @param cashbackRate initializes Cashback rate
	*/
	public PreferredCustomer(String firstName , String lastName ,
			String customerLevel , double totalPurchases ,
			int cashbackRate )
	{
		super(firstName,lastName,customerLevel,totalPurchases);
		this .cashbackRate= cashbackRate;
	}

	/**
	 * Gets the cashbackRate of this object  
	 * @return int
	 */
	
	public int getCashbackRate()
	{
		return cashbackRate;
	}

	/**
	 * Sets the cashbackRate of this object
	 * @param cashbackRate - the value to set
	 */
	
	public void setCashbackRate(int cashbackRate)
	{
		this.cashbackRate = cashbackRate;
	}
	
	/* (non-Javadoc)
	 * @see RetailCustomer#incentives()
	 */
	public double incentives()
	{
		double temIncentive=super.incentives();
		double incentive= (cashbackRate*temIncentive)/100;
		incentive=incentive+temIncentive;
		return incentive;
	}
	
	/* (non-Javadoc)
	 * @see RetailCustomer#toString()
	 */
	public String toString()
	{
		String output = super.toString();
		output +=  String.format("%-22s %s%% \n", "Cashback Rate:", cashbackRate);
		return output;
	}
	
}//End of class

