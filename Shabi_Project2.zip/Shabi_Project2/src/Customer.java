/**
* Program Name:		Customer.java
* @author		    Meenu Shabi 0908938
* Date:   		 	Dec 3, 2019
* Purpose:			An abstract superclass from which subclasses will be derived
*/

public abstract class Customer
{
	//Declare instance variables
	private String firstName;
	private String lastName;
	private String customerID;
	private String customerLevel;
	
	//3-Argument constructor
	/**
	  * Constructs a new Customer object
	  * @param firstName initialize First Name
	  * @param lastName initialize Last Name
	  * @param customerLevel initializes Customer Level
	*/
	public Customer(String firstName, String lastName, String customerLevel)
	{
		this.firstName=firstName;
		this.lastName= lastName;
		this.customerLevel=customerLevel;
		setCustomerID();
	}

	/**
	 * Gets the firstName of this object  
	 * @return String
	 */
	
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * Gets the lastName of this object  
	 * @return String
	 */
	
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * Gets the customerID of this object  
	 * @return String
	 */
	
	public String getCustomerID()
	{
		return customerID;
	}

	/**
	 * Gets the customerLevel of this object  
	 * @return String
	 */
	
	public String getCustomerLevel()
	{
		return customerLevel;
	}

	/**
	 * Sets the firstName of this object
	 * @param firstName - the value to set
	 */
	
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * Sets the lastName of this object
	 * @param lastName - the value to set
	 */
	
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * Sets the customerID of this object
	 */
	
	public void setCustomerID()
	{
		//Creates a unique customer ID made up of this pattern: LASTNAME-12345
		
				customerID = "";
				if(lastName.length()>=4)
				{
					String fristFourChar=lastName.substring(0,4);
					customerID+= fristFourChar.toUpperCase();
				}
				else if(lastName.length()==1)
				{
					customerID+=lastName.toUpperCase()+"XXX";
				}
				else if(lastName.length()==2)
				{
					customerID+=lastName.toUpperCase()+"XX";
				}
				else if(lastName.length()==3)
				{
					customerID+=lastName.toUpperCase()+"X";
				}
					
				
				customerID += "-";
				//Generate five random numbers between 0-9
				for(int i = 0; i < 5; i++)
					customerID += (int)(Math.random() * 9);
				
					
	}

	/**
	 * Sets the customerLevel of this object
	 * @param customerLevel - the value to set
	 */
	
	public void setCustomerLevel(String customerLevel)
	{
		this.customerLevel = customerLevel;
	}
	
	/**
	  *  Calculate incentive
	  * @return double
	  */
	public abstract double incentives();
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
		String output = "";
		output += customerID+", ";
		output +=firstName+" " ;
		output += lastName+"\n";
		output+=customerLevel;
		return output;
	}	
	
	
}
//End of class

