

/**
* Program Name:		CustomerTester.java
* @author		    Meenu Shabi 0908938
* Date:   		 	Dec 4, 2019
* Purpose:			To test objects of the Customer hierarchy
*/

public class CustomerTester
{
	
	public static void main(String[] args)
	
	{
		//1.Title
		
		System.out.println("Welcome to the Customer tester!");
		System.out.println("----------------------------------------------------------------------------------------------------");
		System.out.println("This program will instantiate objects of the Customer hierarchay and test their methods");
		System.out.println("----------------------------------------------------------------------------------------------------");
				
		 //1.Create an array customer
		Customer [] customerArray = new Customer[3];
		
		//2. Create customer object
		BusinessCustomer Oza = new BusinessCustomer("Vishal", "Oza", "Business Customer",
				"HomeDepot", 10, 3105.50);
		RetailCustomer Taday  =  new RetailCustomer("Aira", "Taday", "Retail Customer", 11200.00);
		PreferredCustomer Li = new PreferredCustomer("Yilu", "Li", "Preferred Customer", 6456.85, 5);
		
		//3. Assign customer object to array
		customerArray[0] = Oza;
		customerArray[1] = Taday;
		customerArray[2] = Li;
		
		//4. Print elements of array(Polymorphism)
		for (int i =0; i < customerArray.length; i++)
		{
	        System.out.println( customerArray[i].toString());
	    }
		
		//5. Print customer�s full name and the incentives he/she is entitled to.
		for (int i =0; i < customerArray.length; i++)
		{
	        System.out.println( customerArray[i].getFirstName()+" "+ customerArray[i].getLastName()+ 
	        	 String.format("%-18s $%,3.2f \n", " earns a discount incentive of ", customerArray[i].incentives()));
	        
	    }
		
		//6. Creating three objects
		BusinessCustomer Singh = new BusinessCustomer("Ramandeep", "Singh", "Business Customer",
				"Starbucks", 15, 9875.25);
		RetailCustomer Wu  =  new RetailCustomer("Shiqi", "Wu", "Retail Customer", 3100.50);
		PreferredCustomer Kaur = new PreferredCustomer("Amandeep", "Kaur", "Preferred Customer", 10450.00, 10);
		//7. Print new customer objects
		System.out.println(Singh.toString());
		System.out.println(Wu.toString());
		System.out.println(Kaur.toString());
		
		//8. Test setter methods
		Singh.setTotalPurchases(8895.00);
		Singh.setDiscountRate(12);
		Wu.setTotalPurchases(100500.00);
		Kaur.setTotalPurchases(14987.24);
		Kaur.setLastName("Kaur-Ruhil");
		Kaur.setCashbackRate(13);
		
		//9. Print Changes
		System.out.println(Singh.toString());
		System.out.println(Wu.toString());
		System.out.println(Kaur.toString());
	
	}//End of main method

}//End of class

