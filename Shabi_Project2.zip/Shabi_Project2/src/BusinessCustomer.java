/**
* Program Name:		BusinessCustomer.java
* @author		    Meenu Shabi 0908938
* Date:   		 	Dec 3, 2019
* Purpose:			To create a template for business customer object, extends customer
*/

public class BusinessCustomer extends Customer
{
	//Declare instance variables
	private String companyName;
	private int discountRate;
	private double totalPurchases;
	
	//6-argument constructor
	/**
	  * Constructs a new BusinessCustomer object
	  * @param firstName initializes First name
	  * @param lastName initializes Last name
	  * @param customerLevel initializes Customer level
	  * @param companyName initializes Company name
	  * @param discountRate initializes Discount rate
	  * @param totalPurchases initializes Total purchases
	*/
	public BusinessCustomer(String firstName , String  lastName,
			String customerLevel, String companyName,
			int discountRate, double totalPurchases)
	{
		super(firstName, lastName, customerLevel);
		this.companyName=companyName;
		this.discountRate=discountRate;
		this.totalPurchases=totalPurchases;
	}

	/**
	 * Gets the companyName of this object  
	 * @return String
	 */
	
	public String getCompanyName()
	{
		return companyName;
	}

	/**
	 * Gets the discountRate of this object  
	 * @return int
	 */
	
	public int getDiscountRate()
	{
		return discountRate;
	}

	/**
	 * Gets the totalPurchases of this object  
	 * @return double
	 */
	
	public double getTotalPurchases()
	{
		return totalPurchases;
	}

	/**
	 * Sets the companyName of this object
	 * @param companyName - the value to set
	 */
	
	public void setCompanyName(String companyName)
	{
		this.companyName = companyName;
	}

	/**
	 * Sets the discountRate of this object
	 * @param discountRate - the value to set
	 */
	
	public void setDiscountRate(int discountRate)
	{
		this.discountRate = discountRate;
	}

	/**
	 * Sets the totalPurchases of this object
	 * @param totalPurchases - the value to set
	 */
	
	public void setTotalPurchases(double totalPurchases)
	{
		this.totalPurchases = totalPurchases;
	}
	
	/* (non-Javadoc)
	 * @see Customer#incentives()
	 */
	public double incentives()
	{
	    double tempDiscountRate= discountRate /100.0;
		double incentive= totalPurchases * tempDiscountRate;
		return incentive;
	}
	
	/* (non-Javadoc)
	 * @see Customer#toString()
	 */
	public String toString()
	{
		String output = super.toString();
		output += String.format("%-4s %s \n", " for", companyName);
		output += String.format("%-22s $%,3.2f \n", "Total Purchases:", totalPurchases);
		output += String.format("%-22s %d%% \n", "Discount Rate:", discountRate);
		output += String.format("%-22s $%,3.2f \n", "Discount Incentive:", incentives());
		output += String.format("%-22s $%,3.2f \n", "Net Purchases:", totalPurchases-incentives());
		return output;
	}

}//End of class

