/**
* Program Name:		RetailCustomer.java
* @author		    Meenu Shabi 0908938
* Date:   		 	Dec 3, 2019
* Purpose:			To create a template for retail customer object, extends customer
*/

public class RetailCustomer extends Customer
{
	//Declare instance variables
	private double totalPurchases;
	
	
	/**
	  * Constructs a new RetailCustomer object
	  * @param firstName initializes First name
	  * @param lastName initializes Last name
	  * @param customerLevel initializes Customer level
	  * @param totalPurchases initializes Total Purchases
	*/
	public RetailCustomer(String firstName , String lastName ,
			String customerLevel ,double totalPurchases)
	{
		super(firstName, lastName, customerLevel);
		this.totalPurchases=totalPurchases;
	}
	
	/**
	 * Gets the totalPurchases of this object  
	 * @return double
	 */
	
	public double getTotalPurchases()
	{
		return totalPurchases;
	}
	
	/**
	 * Sets the totalPurchases of this object
	 * @param totalPurchases - the value to set
	 */
	
	public void setTotalPurchases(double totalPurchases)
	{
		this.totalPurchases = totalPurchases;
	}
	
	/**
	  *  Determines the discount rate based on total purchases
	  * @return int
	  */
	public int findDiscountRate()
	{
		int discountRate=0;
		if(totalPurchases>10000)
			discountRate=15;
		else if(totalPurchases>5000)
			discountRate=10;
		else if(totalPurchases>1000)
			discountRate=5;
		return discountRate;
	}
	
	/* (non-Javadoc)
	 * @see Customer#incentives()
	 */
	public double incentives()
	{
		double incentive= totalPurchases * ( findDiscountRate()/100.0);      
		return incentive;
	}
	
	/* (non-Javadoc)
	 * @see Customer#toString()
	 */
	public String toString()
	{
		String output = super.toString();
		output += String.format("%-23s $%,3.2f \n", "\nTotal Purchases:", totalPurchases);
		output += String.format("%-22s %d%% \n", "Discount Rate:", findDiscountRate());
		output += String.format("%-22s $%,3.2f \n", "Incentive:", incentives());
		output += String.format("%-22s $%,3.2f \n", "Net Purchase:", totalPurchases-incentives());
		return output;
	}

}//End of class

