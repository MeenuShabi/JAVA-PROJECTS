/**
* Program Name:		CarnivalRide.java
* @author		    Meenu Shabi 0908938
* Date:   		 	Dec 14, 2019
* Purpose:			An abstract superclass from which subclasses will be derived
*/

public abstract class CarnivalRide
{
	//Declare instance variables
	private String type;
	private long duration;
	private String name;
	
	/**
	  * Constructs a new CarnivalRide object
	  * @param type initialize Type
	  * @param duration initializes Duration
	*/
	public CarnivalRide(String type, long duration)
	{
		this.type = type;
		this.duration = duration;
		this.name = "Unknown";
	}
	
	/**
	  * Constructs a new CarnivalRide object
	  * @param type initialize Type
	  * @param duration initializes Duration
	  * @param name initializes Name
	*/
	public CarnivalRide(String type, long duration, String name)
	{
		this.type = type;
		this.duration = duration;
		this.name = name;
	}

	/**
	 * Gets the type of this object  
	 * @return String
	 */
	
	public String getType()
	{
		return type;
	}

	/**
	 * Gets the duration of this object  
	 * @return long
	 */
	
	public long getDuration()
	{
		return duration;
	}

	/**
	 * Gets the name of this object  
	 * @return String
	 */
	
	public String getName()
	{
		return name;
	}

	/**
	 * Sets the type of this object
	 * @param type - the value to set
	 */
	
	public void setType(String type)
	{
		this.type = type;
	}

	/**
	 * Sets the duration of this object
	 * @param duration - the value to set
	 */
	
	public void setDuration(long duration)
	{
		this.duration = duration;
	}

	/**
	 * Sets the name of this object
	 * @param name - the value to set
	 */
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	/**
	  *  Abstract method and will be implimented in subclasses
	  * @return String
	  */
	public abstract String fearFactor();
	
	/**
	  *  Abstract method and will be implimented in subclasses
	  * @return String
	  */
	public abstract String aboutRide();
	
	/**
	  *  Method to convert duration to minutes
	  * @return Add a type here
	  */
	public int minute()
	{
		int durationInMin = (int)duration/1000/60;
		return durationInMin;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
		String output= "";
		output += String.format("%-4s %s \n", "Type:", type);
		output += String.format("%-4s %d \n", "Duration:",duration);
		output += String.format("%-4s %s \n", "Name:", name);
		return output;
	}	
	
}//End of class

