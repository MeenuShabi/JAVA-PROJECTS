/**
* Program Name:		WaterRide.java
* @author		    Meenu Shabi 0908938
* Date:   		 	Dec 14, 2019
* Purpose:			To create a template for WaterRide object, extends CarnivalRide
*/

public class WaterRide extends CarnivalRide
{
	//Declare instance variables
	private double waterdrop;
	
	/**
	  * Constructs a new WaterRide object
	  * @param duration initializes Duration
	  * @param waterdrop initializes waterdrop
	*/
	public WaterRide(long duration, double waterdrop)
	{
		super("Water Ride",duration);
		this.waterdrop = waterdrop;
	}
	
	
	/**
	  * Constructs a new WaterRide object
	  * @param duration initializes Duration
	  * @param waterdrop initializes waterdrop
	  * @param String initializes Name
	*/
	public WaterRide(long duration, double waterdrop, String name)
	{
		super("Water Ride",duration,name);
		this.waterdrop = waterdrop;	
	}


	/**
	 * Gets the waterdrop of this object  
	 * @return double
	 */
	
	public double getWaterdrop()
	{
		return waterdrop;
	}


	/**
	 * Sets the waterdrop of this object
	 * @param waterdrop - the value to set
	 */
	
	public void setWaterdrop(double waterdrop)
	{
		this.waterdrop = waterdrop;
	}
	
	/* (non-Javadoc)
	 * @see CarnivalRide#fearFactor()
	 */
	public String fearFactor()
	{
		//Description based on duration in minute
		String durationMessage="";
		if (minute() >7)
			durationMessage+= "long and engaging";
		else if (minute() >5)
			durationMessage+= "fun and respectable";
		else if(minute() >4)
			durationMessage+= "very short";
		
		//Description based on waterdrop
		String waterDropMessage= "";
		if (waterdrop>40)
			waterDropMessage= "exhilarating";
		else if (waterdrop >20)
			waterDropMessage= "intermediate";
		else if(waterdrop <20)
			waterDropMessage= "moderate";
		String output= "It is both " + durationMessage + " and is " + waterDropMessage +".";
		return output;		
	}
	
	
	/* (non-Javadoc)
	 * @see CarnivalRide#aboutRide()
	 */
	public String aboutRide()
	{
		String output="";
		output+="This carnival ride is a " + getType() +", and its name is "+getName()+ ".";
		output+="\n"+fearFactor()+"\nThis ride last "+minute()+ " minutes and has waterdrop of "+waterdrop+" meters.";
		return output;
	}
	
	
	/* (non-Javadoc)
	 * @see CarnivalRide#toString()
	 */
	public String toString()
	{
		String output = super.toString();
		output += String.format("%-4s %s \n", "Water Drop:", waterdrop);
		return output;
	}

}//End of class

