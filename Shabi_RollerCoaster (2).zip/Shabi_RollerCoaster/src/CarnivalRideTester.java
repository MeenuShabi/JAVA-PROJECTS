/**
* Program Name:		CarnivalRideTester.java
* @author		    Meenu Shabi 0908938
* Date:   		 	Dec 14, 2019
* Purpose:			To test objects of the CarnivalRide hierarchy
*/

public class CarnivalRideTester
{

	public static void main(String[] args)
	{
		//1.Title
		System.out.println("Welcome to the Carnival Ride tester!");
		System.out.println("----------------------------------------------------------------------------------------------------");
		System.out.println("This program will instantiate objects of the Carnival Ride hierarchay and test their methods");
		System.out.println("----------------------------------------------------------------------------------------------------");

		//2. Create rollercoaster object using 2-arg constructor
		Rollercoaster R1 = new Rollercoaster(300000, 3);
		
		//3. Create rollercoaster object using 3-arg constructor
		Rollercoaster R2 = new Rollercoaster(420000, 5, "Rocky Roller");
		
		//4. Create waterdrop object using 2-arg constructor
		WaterRide W1  =  new WaterRide(200000,18);
		
		//5. Create waterdrop object using 3-arg constructor
		WaterRide W2  =  new WaterRide(290000,35,"River Nile");
		
		//6. Print objects by calling toString()
		System.out.println(R1.toString());
		System.out.println(R2.toString());
		System.out.println(W1.toString());
		System.out.println(W2.toString());
		
		//7. Test getter method 
		System.out.println("Ride type = "+W2.getType());
		System.out.println("Ride name = "+W2.getName());
		System.out.println("Ride duration = "+W2.getDuration());
		System.out.println("Ride water drop = "+W2.getWaterdrop());
		
		//8. Test setter method
		W2.setWaterdrop(95);
		R1.setName("King Kong");
		
		//9. Print modified data
		System.out.println("\nModified objects:\nRide water drop = " +W2.getWaterdrop());
		System.out.println("Ride name = "+ R1.getName());
		
		//10. CarnivalRide Arraylist()
		CarnivalRide [] rideArray = new CarnivalRide[4];
		rideArray[0] = R1;
		rideArray[1] = R2;
		rideArray[2] = W1;
		rideArray[3] = W2;
		
		//11. Print aboutRide() using arrayList
		for (int i =0; i < rideArray.length; i++)
		{
	        System.out.println( "\n"+rideArray[i].aboutRide());
	    }
		
	}//End of main method

}//End of class

