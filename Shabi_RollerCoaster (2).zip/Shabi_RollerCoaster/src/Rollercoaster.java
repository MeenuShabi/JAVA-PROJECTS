/**
* Program Name:		Rollercoaster.java
* @author		    Meenu Shabi 0908938
* Date:   		 	Dec 14, 2019
* Purpose:			To create a template for RollerCoaster object, extends CarnivalRide
*/

public class Rollercoaster extends CarnivalRide
{
	//Declare instance variables
	private int loops;
	
	/**
	  * Constructs a new Rollercoaster object
	  * @param duration initializes Duration
	  * @param loops initializes Loops
	*/
	public Rollercoaster(long duration, int loops)
	{
		super("RollerCoaster",duration);
		this.loops= loops;
	}
	
	/**
	  * Constructs a new Rollercoaster object
	  * @param duration initializes Duration
	  * @param loops initializes Loops
	  * @param name initializes Name
	*/
	public Rollercoaster(long duration, int loops, String name)
	{
		super("RollerCoaster", duration,name);
		this.loops= loops;
	}

	/**
	 * Gets the loops of this object  
	 * @return int
	 */
	
	public int getLoops()
	{
		return loops;
	}

	/**
	 * Sets the loops of this object
	 * @param loops - the value to set
	 */
	
	public void setLoops(int loops)
	{
		this.loops = loops;
	}
	
	/* (non-Javadoc)
	 * @see CarnivalRide#fearFactor()
	 */
	public String fearFactor()
	{
		//Description based on duration
		String durationMessage="";
		if (minute()>6)
			durationMessage+= "terrifying";
		else if (minute()>3)
			durationMessage+= "scary";
		else if(minute()>2)
			durationMessage+= "not Scary";
		
		//Description based on loops
		String loopsMessage= "";
		if (loops>=5)
			loopsMessage+= "exhilarating";
		else if (loops >=3)
			loopsMessage+= "intermediate";
		else if(loops >=2)
			loopsMessage+= "moderate";
		String output= "It is both " + durationMessage + " and is " + loopsMessage+ ".";
		return output;		
	}
	
	/* (non-Javadoc)
	 * @see CarnivalRide#aboutRide()
	 */
	public String aboutRide()
	{
		String output="";
		output+="This carnival ride is a " + getType() +", and its name is "+getName()+ ".";
		output+="\n"+fearFactor()+"\nThis ride last "+minute()+ " minutes and has "+loops+" number of loops.";
		return output;
	}
	
	/* (non-Javadoc)
	 * @see CarnivalRide#toString()
	 */
	public String toString()
	{
		String output = super.toString();
		output += String.format("%-4s %s \n", "Loops:",loops);
		return output;
	}
	
}//End of class

